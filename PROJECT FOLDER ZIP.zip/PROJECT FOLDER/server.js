const express = require("express");
const bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");
const path = require("path");

const app = express();
const port = 3000;


const uri =
  "mongodb+srv://rithi0423:Swetharithu23@cluster0.xsk8b.mongodb.net/?retryWrites=true&w=majority";

const client = new MongoClient(uri);

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, "public")));

async function run() {
  try {
    await client.connect();
    console.log("✅ Connected to MongoDB Atlas");

    const database = client.db("User_details");
    const signupCollection = database.collection("Sign_up");

    app.post("/signup", async (req, res) => {
      const { Name, Email, Password, Conf_pass } = req.body;

      try {
        const existingUser = await signupCollection.findOne({ Email });

        if (existingUser) {
          return res.status(400).send("User already exists.");
        }

        if (Password !== Conf_pass) {
          return res.status(400).send("Passwords do not match.");
        }

        const newUser = { Name, Email, Password };
        const result = await signupCollection.insertOne(newUser);

        if (result.acknowledged) {
          console.log("New user registered");
          res.status(201).send("User registered successfully.");
        } else {
          res.status(500).send("Failed to register user.");
        }
      } catch (err) {
        console.error(" Error during signup:", err);
        res.status(500).send("Server error during signup.");
      }
    });

   
    app.post("/signin", async (req, res) => {
      const { email, password } = req.body;

      try {
        const user = await signupCollection.findOne({
          Email: email,
          Password: password,
        });

        if (user) {
          console.log(" Sign-in successful for:", email);
          res.status(200).send("Sign-in successful!");
        } else {
          res.status(401).send("Invalid email or password.");
        }
      } catch (err) {
        console.error(" Error during sign-in:", err);
        res.status(500).send("Server error during sign-in.");
      }
    });
  } catch (err) {
    console.error(" Could not connect to MongoDB:", err);
    process.exit(1);
  }
}

run().catch(console.dir);

app.listen(port, () => {
  console.log(`🚀 Server running at http://localhost:${port}`);
});
